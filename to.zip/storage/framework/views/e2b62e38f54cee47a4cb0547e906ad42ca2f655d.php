<?php if(Session::has('sweet_alert.alert')): ?>
    <script>
        swal(<?php echo Session::pull('sweet_alert.alert'); ?>);
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\re-master\vendor\uxweb\sweet-alert\src\SweetAlert/../views/alert.blade.php ENDPATH**/ ?>