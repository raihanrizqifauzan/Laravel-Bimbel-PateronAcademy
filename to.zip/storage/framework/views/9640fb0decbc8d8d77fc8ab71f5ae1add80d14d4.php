<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="row" style="padding-left:30px;"">
  <div class="col-lg-8 col-md-12 col-sm-12 col-12 mb-1">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-6 col-12 mb-3">
        <a href="<?php echo e(route('fitur-tryout.create')); ?>" class="btn btn-success btn-rounded btn-fw" style="width:100%">
          <i class="fa fa-plus"></i> Tambah Soal Try Out
        </a>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-6 col-12 mb-3">
        <a href="<?php echo e(route('video.create')); ?>" class="btn btn-info btn-rounded btn-fw" style="width:100%">
          <i class="fa fa-plus"></i> Tambah Video Tutorial
        </a>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-6 col-12 mb-3">
        <a href="<?php echo e(route('materi-pateron.create')); ?>" class="btn btn-dark btn-rounded btn-fw" style="width:100%">
          <i class="fa fa-plus"></i> Tambah Materi PDF
        </a>
      </div>
    </div>
  </div>  
</div>
         <div class="container-fluid">
            <br/>

            <!-- Content Row -->
            <div class="row">
              <div class="col-xl-12 col-lg-12">
                <div class="card shadow mb-4">
                  <!-- Card Body -->
                  <div class="card-body">
                    <div class="row" style="padding: 20px;">
                      <div
                        class="col-lg-8 col-md-10 col-sm-12 col-12  offset-lg-2 mb-3"
                      >
                        <div class="card">
                            <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <h5 class="card-title paket"> Paket Belajar <?php echo e($da->bidang); ?></h5>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <div class="card-body">
                              <ul class="detail">
                                <li class="title-list">Daftar Try Out</li>
                              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sub-list">
                                  Try Out <?php echo e($datas -> try_out); ?> 
                                  <a href="<?php echo e(url('fitur-tryout/detail/'.$datas->id_bidang.'/'.$datas->id_try_out)); ?>" >
                                    <button class="btn btn-dark start-btn">Lihat Soal Try Out</button>
                                  </a>
                                  <div class="clear"></div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 <li class="title-list">Daftar Video Tutorial</li>
                              <?php $__currentLoopData = $datat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sub-list">
                                  Video Tutorial <?php echo e($datat -> judul); ?> 
                                  <div class="pull-right">
                                  <a href="<?php echo e(url('detail-video/'.$datat->id)); ?>">
                                    <button class="btn btn-xs btn-info" >Detail </button>
                                  </a>
                                  <a href="<?php echo e(route('paket-belajar.edit',$datat->id_bidang)); ?>" >
            
                                    <button class="btn btn-dark btn-info" >Edit</button>
                                  </a>
                                  <nbsp>
                                  <a href="<?php echo e(url('delete-video',$datat->id)); ?>">
                                      <button class="btn btn-xs btn-danger" onclick="return confirm('Apakah Anda Yakin akan menghapus Video Ini? ')">Delete</button>
                                  </a>
                                  </div>
                                     <div class="clear"></div>
                               
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <li class="title-list">Daftar Materi PDF</li>
                              <?php $__currentLoopData = $dataf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sub-list">
                                  Tutorial <?php echo e($dataf -> judul_materi); ?> 
                                  <div class="pull-right">
                                  <a href="<?php echo e(asset('images/materi/pdf/'.$dataf->file)); ?>" target="_blank">
                                    <button class="btn btn-xs btn-info">Detail </button>
                                  </a>
                                  <nbsp>
                                  <a href="<?php echo e(url('/delete-materi/'.$dataf->id_materi)); ?>" >
                                    <button class="btn btn-xs btn-danger" onclick="return confirm('Apakah Anda Yakin akan menghapus Video Ini? ')">Delete</button>
                                  </a>
                                  </div>
                                  <div class="clear"></div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </ul >
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\re-master\resources\views/soal/pilih-tryout.blade.php ENDPATH**/ ?>