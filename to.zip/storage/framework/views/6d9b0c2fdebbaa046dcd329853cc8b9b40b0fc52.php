<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
          <div class="container-fluid">
            <br />

            <!-- Content Row -->
            <div class="row">
              <div class="col-xl-12 col-lg-12">
                <div class="card shadow mb-4">
                  <!-- Card Body -->
                  <div class="card-body">
                    <div class="row" style="padding: 20px;">
                      <div
                        class="col-lg-8 col-md-10 col-sm-12 col-12  offset-lg-2 mb-3"
                      >
                        <div class="card">
                          <?php $__currentLoopData = $dat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <h5 class="card-title paket"> Belajar <?php echo e($stud->bidang); ?></h5>
                          <img
                            src="<?php echo e(asset('images/paket-belajar/'.$stud->foto)); ?>"
                            class="card-img-top"
                            alt="..."
                          />
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <div class="card-body">
                              <ul class="detail">
                                <li class="title-list">Daftar Try Out</li>
                              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sub-list">
                                  Try Out <?php echo e($datas -> try_out); ?> 
                                  <a href="<?php echo e(url('/tryout-start/'.$datas->id_try_out.'/'.$datas->id_bidang)); ?>" >
                                    <button class="btn btn-dark start-btn">Kerjakan Soal Try Out Ini</button>
                                  </a>
                                  <div class="clear"></div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 <li class="title-list">Daftar Video Tutorial</li>
                              <?php $__currentLoopData = $datat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sub-list">
                                  Video Tutorial <?php echo e($datat -> judul); ?> 
                                  <a href="<?php echo e(url('/video-belajar/'.$datat->id)); ?>" class="pull-right" >
                                    <button class="btn btn-xs btn-info">Lihat Video </button>
                                  </a>
                                    <div class="clear"></div>
                               
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <li class="title-list">Daftar Materi PDF</li>
                              <?php $__currentLoopData = $dataf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sub-list">
                                  Tutorial <?php echo e($dataf -> judul_materi); ?> 
                                  <div class="pull-right">
                                  <a href="<?php echo e(asset('images/materi/pdf/'.$dataf->file)); ?>" target="_blank">
                                    <button class="btn btn-xs btn-info">Lihat Materi </button>
                                  </a>
                                  <nbsp>
                                  <a href="<?php echo e(url('/rangkuman-upload/'.$dataf->id_materi.'/'.$dataf->id_bidang)); ?>" >
                                    <button class="btn btn-xs btn-danger">Upload Tugas </button>
                                  </a>
                                  </div>
                                  <div class="clear"></div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </ul >
                          </div>
                        </div>
                      </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\re-master\resources\views/produk/mulai-belajar.blade.php ENDPATH**/ ?>