<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('tryout.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-xl-12">
                            <div class="card">
                                <center>    
                                    Waktu
                                <div id="countdown" > 
                                    </div>
                                    
                            </center>
                            <br>
                             <div id="tempat" > 
                                    </div>
             
       
                                <div class="card-header">
                                    <h4 class="box-title">Soal 
                                        <label class="pull-right">
                                            <a href="#">Soal ke <?php echo e($start_no+1); ?> /<?php echo e($total_s); ?>

                                            </a>
                                        </label>
                                    </h4>
                                    <br>
                                </div>
                                <br>
                                      <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
                             <br>
                 <input type="hidden" name="waktu" id="waktu">
                             <script>
                  
                CountDownTimer('<?php echo e($times); ?>','<?php echo e($ti); ?>','countdown');
                function CountDownTimer(dt,di, id)
                {  

                    var end = new Date();
                                            
                    if (dt == di) {
                    //alert(dt);
                    //alert(di);
                    
                    var tam=end.getMinutes();
                    dt=parseInt(dt);
                    tam=parseInt(tam);    
                    var waktos=dt-tam;
                    end.setMinutes(tam+dt);
                   // document.getElementById('tempat').innerHTML =waktos;  
                    }else{ 
                      //  alert(di);
                   
                        var end = new Date(di);
                    
                    }
                    var _second = 1000;
                    var _minute = _second * 60;
                    var _hour = _minute * 60;
                    var _day = _hour * 24;
                    var timer;
                    timer = setInterval(function showRemaining() {
                        var now = new Date();
                        //var tanggal= now.substring(1,3);
                        
                        var distance = end - now;
                        document.getElementById('waktu').value =end;  
                   
                        if(end <= now){
                           clearInterval(timer);
                          window.location.href='/hasil-tryout';  
                        } 
                        var days = Math.floor(distance / _day);
                        var hours = Math.floor((distance % _day) / _hour);
                        var minutes = Math.floor((distance % _hour) / _minute);
                        var seconds = Math.floor((distance % _minute) / _second);
 
                        document.getElementById(id).innerHTML = hours + ':';
                        document.getElementById(id).innerHTML += minutes + ':';
                        document.getElementById(id).innerHTML += seconds ;
                   //    document.getElementById('waktu').value =waktos ;
                        
                    }, 1000);
                }
            </script>
                              
                 
            <br>
                 <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success">Petunjuk ! </span> Gunakan Petunjuk <?php echo e($data->petunjuk); ?> Untuk menjawab Pertanyaan Ini
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <hr>
                   
                                <div class="card-body">
                                    <div class="form-group">
                                      <?php if($data ->gambar_soal): ?> 
                                       <CENTER> 
                                        <a href="<?php echo e(asset('images/soal/'.$data->gambar_soal)); ?>" data-fancybox="gallery">

                                            <img width="300" height="300" src="<?php echo e(asset('images/soal/'.$data->gambar_soal)); ?>">
                                           </a>
                                        </CENTER>
                                       <br>
                                       <?php endif; ?>
                                       <p class="text-dark">
                                        <!-- <?php echo e($data->soal); ?> -->
                                        <?php echo nl2br(e($data->soal)); ?>

                                        </p>
                                       <hr>
                                      <!--  <img src="https://latex.codecogs.com/gif.latex?\frac{(x^2-y^2)}{(x^2+y^2)}" border="0"/>
                                       --> 
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="jawaban" value="A"> A.
                                            <?php if($data->pengecekan == 'ya'): ?>
                                                <a href="<?php echo e(asset('images/soal/'.$data->option_a)); ?>" data-fancybox="gallery">

                                                <img width="300" height="300" src="<?php echo e(asset('images/soal/'.$data->option_a)); ?>">
                                               </a>
                                        
                                            <?php else: ?>
                                             <?php echo e($data->option_a); ?>

                                            <?php endif; ?>
                                        </label>
                                        <br>
                                        <label>
                   <input type="radio" name="jawaban" value="B" > B. 
                                            <?php if($data->pengecekan == 'ya'): ?>
                                                <a href="<?php echo e(asset('images/soal/'.$data->option_b)); ?>" data-fancybox="gallery">

                                                <img width="300" height="300" src="<?php echo e(asset('images/soal/'.$data->option_b)); ?>">
                                               </a>
                                        
                                            <?php else: ?>
                                     
                                            <?php echo e($data->option_b); ?>

                                            <?php endif; ?>
                                        </label>
                                        <br>
                                        <label>
                                            <input type="radio" name="jawaban" value="C"> C. 
                                            <?php if($data->pengecekan == 'ya'): ?>
                                                <a href="<?php echo e(asset('images/soal/'.$data->option_c)); ?>" data-fancybox="gallery">

                                                <img width="300" height="300" src="<?php echo e(asset('images/soal/'.$data->option_c)); ?>">
                                               </a>
                                        
                                            <?php else: ?>
                                     
                                            <?php echo e($data->option_c); ?>

                                            <?php endif; ?>

                                        </label>
                                        <br>
                                        <label>
                                            <input type="radio" name="jawaban" value="D"> D. 
                                            <?php if($data->pengecekan == 'ya'): ?>
                                                <a href="<?php echo e(asset('images/soal/'.$data->option_d)); ?>" data-fancybox="gallery">

                                                <img width="300" height="300" src="<?php echo e(asset('images/soal/'.$data->option_d)); ?>">
                                               </a>
                                        
                                            <?php else: ?>
                                     
                                            <?php echo e($data->option_d); ?>

                                            <?php endif; ?>
                                        </label>
                                        <br>
                                        <label>
                                            <input type="radio" name="jawaban" value="E"> E. 
                                            <?php if($data->pengecekan == 'ya'): ?>
                                                <a href="<?php echo e(asset('images/soal/'.$data->option_e)); ?>" data-fancybox="gallery">

                                                <img width="300" height="300" src="<?php echo e(asset('images/soal/'.$data->option_e)); ?>">
                                               </a>
                                        
                                            <?php else: ?>
                                     
                                            <?php echo e($data->option_e); ?>

                                            <?php endif; ?>
                                             <input type="hidden" name="kunci" value="<?php echo e($data->kunci); ?>">

                                            <input type="hidden" name="bidang" value="<?php echo e($akses); ?>">
                                            <input type="hidden" name="to" value="<?php echo e($aksesto); ?>">
                                                
                                            <input type="hidden" name="nilai" value="<?php echo e($nilai); ?>">
                                            
                                            

                                            <input type="hidden" name="off" value="<?php echo e($total_s); ?>">
                                         
                                        </label>  
                                        <br>
                                        
                                            
                                            
                                </div>
                      
                                <br>
                                <br>
                         <div></div>       
                        <button type="submit"  id="submit" class="btn btn-primary  pull-right">
                                Next Soal
                        </button>
                        <?php if($start_no != 0): ?>
                        <a href="<?php echo e(url('/back-tryoutsoal')); ?>" class="btn btn-light" >Back</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</p>
</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\re-master\resources\views/tryout/soal.blade.php ENDPATH**/ ?>