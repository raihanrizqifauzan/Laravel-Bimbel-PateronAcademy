<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h1>asdad</h1>
                    <form method="POST" action="<?php echo e(route('setting.store')); ?>">
                           </label>
                            <div class="col-md-12">
                                    <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label for="waktu" class="col-md-12 control-label">Waktu Pengerjaan Try Out <?php echo e($data->try_out); ?> Bidang : <?php echo e($data->bidang); ?> (Dalam Menit)
                                </label>
                                <br>
                                <input  type="number"  class="form-control" name="waktu[]" value="<?php echo e($data->waktu); ?>" required>
                                <?php if($errors->has('waktu1')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('waktu1')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <br>

                                <input type="hidden"  name="id[]" value="<?php echo e($data->id_try_out); ?>">
                                <input type="hidden"  name="idb[]" value="<?php echo e($data->id_bidang); ?>">
                                
                            </div>
                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                    </form>
                </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\re-master\resources\views/setting.blade.php ENDPATH**/ ?>