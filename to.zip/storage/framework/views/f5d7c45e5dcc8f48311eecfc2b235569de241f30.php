<?php $__env->startSection('content'); ?>

    <div class="card-body">
      <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
          </div>
          
          <!-- Content Row -->
          <div class="row">
            <div class="col-xl-12 col-lg-12">
              <div class="card shadow mb-4">
                <!-- Card Body -->
                <div class="card-body">
                  <div class="row" style="padding: 20px;">
                   
                   <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php  
                      $tam=$datas->id_bidang;
                      $pe=0;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($tam == $cek->id_bidang): ?>
                       <?php 
                         $pe=1;
                        ?>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($pe==1): ?>
                    <?php 
                      $pe=0;
                       ?>
                    <?php else: ?>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-12 mb-3">
                      <div class="card">
                        <h5 class="card-title paket">Paket Belajar <br> <?php echo e($datas->bidang); ?> </h5>
                        <img src="images/paket-belajar/<?php echo e($datas->foto); ?>"  class="card-img-top" alt="...">
                        <div class="card-body">
                          <ul class="detail">
                            <li><?php echo e($datas->materi); ?> Modul Belajar</li>
                            <li>Video Pembahasan</li>
                          </ul >
                          <button class="btn daftar-sekarang">
                            <a href="<?php echo e(url('produk-detail/'.$datas->id_bidang)); ?>">Daftar Sekarang</a>
                          </button>
                        </div>
                      </div>
                    </div>

                    <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\re-master\resources\views/home.blade.php ENDPATH**/ ?>