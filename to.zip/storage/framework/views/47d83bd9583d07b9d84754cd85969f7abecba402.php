<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#table').DataTable({
      "iDisplayLength": 50
    });

} );
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row" style="padding:30px">
  <div class="offset-lg-12">
    <a href="<?php echo e(route('fitur-tryout.create')); ?>" class="btn btn-primary btn-rounded btn-fw">
      <i class="fa fa-plus"></i> Tambah Soal Try Out
    </a>
  </div>
</div>
<div class="row mt-3" style="padding:20px;">
  <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body" style="padding:20px">
          <h5 class="card-title pull-left">Data Soal Paket Belajar <?php echo e($paket); ?> </h5>
          <h5 class="card-title pull-right">Try Out  Ke <?php echo e($to); ?></h5>
          
          <div class="table-wrapper">
            <table class="table table-bordered table table-striped" id="table">
              <thead>
                <tr>
                  <th>
                    No
                  </th>
                  <th>
                    Soal
                  </th>
                  <th>
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="py-1">
                    <?php echo e($no++); ?>

                  </td>
                  <td>
                    <?php echo e($data->soal); ?>

                  </td>
                  <td>
                  <div class="btn-group dropdown">
                  <button type="button" class="btn btn-success dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Action
                  </button>
                  <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 30px, 0px);">
                    <a class="dropdown-item" href="<?php echo e(route('fitur-tryout.edit',$data->id_soal)); ?>">Edit </a>
                    <form action="<?php echo e(route('fitur-tryout.destroy',$data->id_soal)); ?>" class="pull-left"  method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('delete')); ?>

                    <button class="dropdown-item" onclick="return confirm('Anda yakin ingin menghapus data ini?')"> Delete
                    </button>
                  </form>
                    
                  </div>
                </div>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        
        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\re-master\resources\views/soal/index.blade.php ENDPATH**/ ?>