# PateronProject
Membuat dan mengembangkan fitur yang ada pada web pateron.org untuk keperluan tryout online pada 25 November 2019.
# perkembangan_web_pateron
